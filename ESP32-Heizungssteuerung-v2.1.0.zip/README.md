# Release v2.1.0 - ESP32 Heizungssteuerung

## 📦 Binaries

Dieses Release enthält die kompilierten Binaries für den ESP32:

- **`firmware.bin`** (1.1 MB) - Die kompilierte Firmware für den ESP32
- **`littlefs.bin`** (1.4 MB) - Das Dateisystem mit den Frontend-Dateien (index.html)

## 🚀 Installation

### Voraussetzungen

- ESP32 DevKit (ESP32-WROOM-32)
- PlatformIO oder esptool.py
- USB-Kabel zum ESP32

### Upload mit esptool.py

```bash
# 1. Firmware flashen (0x10000 = Partitions-Tabelle startet hier)
esptool.py --chip esp32 --port /dev/cu.wchusbserial14410 write_flash 0x10000 firmware.bin

# 2. LittleFS Dateisystem flashen (0x200000 = LittleFS Partition startet hier)
esptool.py --chip esp32 --port /dev/cu.wchusbserial14410 write_flash 0x200000 littlefs.bin

# 3. Bootloader und Partitions-Tabelle (falls nötig)
# Diese sind normalerweise nur beim ersten Flashen nötig
esptool.py --chip esp32 --port /dev/cu.wchusbserial14410 write_flash 0x1000 bootloader.bin
esptool.py --chip esp32 --port /dev/cu.wchusbserial14410 write_flash 0x8000 partitions.bin
```

### Upload mit PlatformIO

```bash
# 1. Firmware hochladen
pio run -t upload

# 2. LittleFS hochladen
pio run -t uploadfs
```

## ⚙️ Konfiguration

Nach dem ersten Boot:

1. **WiFi Setup**: Falls nicht konfiguriert, startet der ESP32 im Access-Point-Modus
   - SSID: `Heizungssteuerung`
   - Passwort: `admin1234`
   - Öffne http://192.168.4.1 im Browser

2. **WiFi konfigurieren**: Gehe zu Einstellungen → WiFi und gib deine WiFi-Daten ein

3. **Telegram Setup** (optional): Gehe zu Einstellungen → Telegram
   - Erstelle einen Bot über @BotFather auf Telegram
   - Gib Bot-Token und Chat-ID ein

## 🔧 Hardware-Anforderungen

**Benötigt:**
- ESP32 DevKit V1 (30 Pin)
- DS18B20 Temperatursensoren (2x, wasserdicht)
- HW-307 Relais-Modul (1-Kanal, Active-Low, 5V)
- USB-Netzteil (5V, 1-2A) - **empfohlen** ✅
- 4.7kΩ Widerstand (für OneWire-Bus)
- JSN-SR04T Ultraschall-Sensor (optional, für Tankfüllstand)

**Optional:**
- LM2596S Spannungsregler (nur bei externer 12V/24V Versorgung nötig)

**Alle Komponenten können direkt am ESP32 betrieben werden:**
- Relais VCC → ESP32 5V Pin
- JSN-SR04T VCC → ESP32 5V Pin  
- DS18B20 VDD → ESP32 3.3V Pin

Siehe `SCHALTPLAN.md` für detaillierte Verdrahtung.

## ✨ Features

- ✅ Relais-Steuerung mit Open-Drain-Mode (HW-307 kompatibel)
- ✅ Wetter-Daten Integration (Open-Meteo API)
- ✅ Telegram Benachrichtigungen
- ✅ DS18B20 Temperatursensoren (Vorlauf/Rücklauf)
- ✅ Automatische Steuerung mit Hysterese
- ✅ Zeitplan-Funktion (bis zu 4 Zeitfenster)
- ✅ Frostschutz
- ✅ Web-Dashboard mit Real-Time Updates
- ✅ Tankfüllstand-Messung (optional, JSN-SR04T)
- ✅ Persistente Einstellungen (NVS)

## 📝 Changelog v2.1.0

### Features
- **UI-Verbesserungen**: System-Informationen (WiFi-Signal, Betriebszeit, NTP-Status) im Header platziert
- **WiFi-Icon**: Farblich kodiertes WiFi-Signal-Icon (grün = gut, rot = schlecht)
- **Klappbare Statistik**: Statistik-Karte kann ein- und ausgeklappt werden (standardmäßig eingeklappt)
- **Platzsparende UI**: Frostschutz in Steuerungskarte integriert, OTA-Update Button im Serial Monitor
- **Sicherheitsvalidierung**: Upload-Validierung für Firmware und Frontend (verhindert versehentliche Uploads)
- **Modal-System**: OTA-Updates in kompaktem Modal-Dialog
- **Automatische Modal-Schließung**: Modal schließt automatisch nach erfolgreichem Upload

### UI-Änderungen
- **Header**: System-Informationen direkt im Header für bessere Übersicht
- **Tankinhalt**: Unter Serial Monitor verschoben für bessere Platznutzung
- **Statistik**: Standardmäßig eingeklappt, klappbar per Pfeil-Icon
- **OTA-Update**: Button im Serial Monitor statt separater Karte

### Bugfixes
- **Modal-Verhalten**: Modal reagiert korrekt auf WebSocket-Nachrichten und schließt nach Upload
- **Datei-Validierung**: Robustere Validierung von Firmware- und Frontend-Dateien

## 📝 Changelog v2.0.0

### Features
- Vollständig funktionsfähige Relais-Steuerung mit Open-Drain-Mode
- Wetter-Daten werden korrekt geladen und angezeigt
- Location-Name wird persistent gespeichert
- Telegram-Benachrichtigungen komplett implementiert

### Bugfixes
- **Relais-Steuerung**: HW-307 Relais-Modul erkennt 3.3V HIGH nicht zuverlässig → Open-Drain-Mode implementiert
- **Wetter-Daten**: Werden jetzt korrekt beim Booten geladen
- **Location-Name**: Wird jetzt persistent in NVS gespeichert

## 🔗 Weitere Informationen

- Repository: https://github.com/s3vdev/Heizungssteuerung
- Dokumentation: Siehe `README.md` und `SCHALTPLAN.md` im Repository

